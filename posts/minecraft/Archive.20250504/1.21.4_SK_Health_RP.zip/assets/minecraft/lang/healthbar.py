
with open("1.txt","w") as f:
    f.write("{\n")
    for i in range(0,101):
        f.write('\t"skapi.healthbar.%d":"%s%s\\udaff\\udf9c",\n'%(i,"\\uf001\\udaff\\udfff"*i,"\\udb00\\udc01"*(100-i)))
    f.write("}")