
execute if score @s skapi.health_temp matches -2147483648..2147483647 run return 1


