
# 实体不存在，实体不在玩家5格以内，则删除列表里的UUID
$execute unless entity $(a) run return run function sklibs:health/tick/_1.noentity with storage skapi.health i
$execute as $(a) at @s unless entity @e[type=player,distance=0..5] run return run function sklibs:health/tick/_1.unloaded with storage skapi.health i

# 实体tick
$execute as $(a) at @s run function sklibs:health/tick/_2
