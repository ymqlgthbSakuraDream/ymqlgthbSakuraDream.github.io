
$data modify entity @s CustomName set value '[{"translate":"space.-50"},{"translate":"skapi.healthbar.$(fade)","color":"yellow"},{"translate":"skapi.healthbar.$(now)","color":"green"},{"text":"$(fade)%","color":"white"}]'

