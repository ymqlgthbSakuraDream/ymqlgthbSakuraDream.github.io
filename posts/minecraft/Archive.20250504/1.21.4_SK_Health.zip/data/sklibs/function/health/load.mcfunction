
scoreboard objectives add skapi.health dummy
scoreboard objectives add skapi.health_max dummy
scoreboard objectives add skapi.health_percent dummy
scoreboard objectives add skapi.health_temp dummy


execute as @e[tag=skhealth] run function sklibs:health/load/_0
data modify storage skapi.health uuids set value []