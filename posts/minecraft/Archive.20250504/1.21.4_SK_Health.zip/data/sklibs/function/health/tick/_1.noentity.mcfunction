
$data remove storage skapi.health uuids[{a:"$(a)"}]
return 0
