
tag @s remove skhealth
data remove entity @s CustomName
data modify entity @s CustomNameVisible set value false
