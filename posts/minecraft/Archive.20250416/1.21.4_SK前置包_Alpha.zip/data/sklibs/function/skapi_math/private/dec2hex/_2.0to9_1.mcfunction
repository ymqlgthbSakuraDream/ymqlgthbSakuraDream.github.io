
$data modify storage skapi.math temp.hexList insert 0 value "$(v)"
