
data modify storage skapi.math temp.hexList set value []

function sklibs:skapi_math/private/dec2hex/_1

data modify storage skapi.arrays temp.l2s set from storage skapi.math temp.hexList
function sklibs:skapi_arrays/list2string
data modify storage skapi.math temp.hexString set from storage skapi.arrays temp.l2sA
