

execute store result storage skapi.math temp.hexChar.v int 1 run scoreboard players get dec._1 skapi.math
function sklibs:skapi_math/private/dec2hex/_2.0to9_1 with storage skapi.math temp.hexChar