
scoreboard players operation dec._1 skapi.math = dec.input skapi.math
scoreboard players operation dec._2 skapi.math = dec.input skapi.math

scoreboard players operation dec._1 skapi.math %= 16 skapi.math

execute if score dec._1 skapi.math matches 0..9 run function sklibs:skapi_math/private/dec2hex/_2.0to9
execute if score dec._1 skapi.math matches 10..15 run function sklibs:skapi_math/private/dec2hex/_2.atof

scoreboard players operation dec._2 skapi.math /= 16 skapi.math
scoreboard players operation dec.input skapi.math = dec._2 skapi.math

execute if score dec.input skapi.math matches 1.. run function sklibs:skapi_math/private/dec2hex/_1
