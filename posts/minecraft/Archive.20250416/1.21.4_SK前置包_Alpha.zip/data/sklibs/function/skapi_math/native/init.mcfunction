
scoreboard objectives add skapi.math dummy


scoreboard players set -1 skapi.math -1
scoreboard players set 1000 skapi.math 1000
scoreboard players set 16 skapi.math 16
