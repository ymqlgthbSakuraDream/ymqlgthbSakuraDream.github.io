
execute if score dec._1 skapi.math matches 10 run data modify storage skapi.math temp.hexList insert 0 value "A"
execute if score dec._1 skapi.math matches 11 run data modify storage skapi.math temp.hexList insert 0 value "B"
execute if score dec._1 skapi.math matches 12 run data modify storage skapi.math temp.hexList insert 0 value "C"
execute if score dec._1 skapi.math matches 13 run data modify storage skapi.math temp.hexList insert 0 value "D"
execute if score dec._1 skapi.math matches 14 run data modify storage skapi.math temp.hexList insert 0 value "E"
execute if score dec._1 skapi.math matches 15 run data modify storage skapi.math temp.hexList insert 0 value "F"
