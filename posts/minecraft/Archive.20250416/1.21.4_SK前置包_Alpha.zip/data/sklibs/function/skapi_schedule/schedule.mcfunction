

$function sklibs:skapi_arrays/native/io/io {input:$(t),output:{data:"storage skapi.schedule input.t"}}
$function sklibs:skapi_arrays/native/io/io {input:$(cmds),output:{data:"storage skapi.schedule input.cmds"}}

function sklibs:skapi_schedule/private/schedule_0 with storage skapi.schedule input