
execute if data storage skapi.schedule list[0] run function sklibs:skapi_schedule/native/tick_0