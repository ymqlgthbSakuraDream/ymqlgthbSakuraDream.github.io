

execute store result score schtick_0 skapi.arrays.temp run data get storage skapi.schedule input.t 1.0
execute store result score schtick_1 skapi.arrays.temp run data get storage skapi.schedule list
scoreboard players operation schtick_0 skapi.arrays.temp -= schtick_1 skapi.arrays.temp
scoreboard players operation schtick_0 skapi.arrays.temp += 1 skapi.arrays.temp
function sklibs:skapi_arrays/range {start:{value:0},stop:{score:"schtick_0 skapi.arrays.temp"},step:{value:1},output:{data:"storage skapi.schedule range"}}
function sklibs:skapi_arrays/foreach {i:{data:"storage skapi.schedule rangeI"},target:{data:"storage skapi.schedule range"},execute:{value:"function sklibs:skapi_schedule/private/schedule_2"}}




