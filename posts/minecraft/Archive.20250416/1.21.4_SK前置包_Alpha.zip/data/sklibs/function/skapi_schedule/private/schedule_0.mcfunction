

$execute unless data storage skapi.schedule list[$(t)] run function sklibs:skapi_schedule/private/schedule_1


$function sklibs:skapi_arrays/extend {a:{data:"storage skapi.schedule list[$(t)]"},b:{value:$(cmds)}}
