
# data modify storage skapi.schedule list set value []
data modify storage skapi.schedule i set value {cmd:[]}
