
data modify storage skapi.schedule i.cmd set from storage skapi.schedule list[0]
function sklibs:skapi_arrays/runcmds {cmds:{data:"storage skapi.schedule i.cmd"}}
data remove storage skapi.schedule list[0]
