data modify storage skapi.arrays temp.ioTemp.char2 set value ""
data modify storage skapi.arrays temp.ioTemp.iScale set value ""