
data modify storage skapi.arrays temp.searchOutput append value 0
execute store result storage skapi.arrays temp.searchOutput[-1] int 1.0 run scoreboard players get searchIndex skapi.arrays.temp
