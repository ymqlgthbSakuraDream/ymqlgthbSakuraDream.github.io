
tellraw @a [{"text":"当前demoS0的值为："},{"nbt":"temp.demoS0","storage":"skapi.arrays"}]

#data modify storage skapi.arrays temp.demoS3 set value {tag:"c3"}
#function sklibs:skapi_arrays/equal {a:"storage skapi.arrays temp.demoS0",b:"storage skapi.arrays temp.demoS3"}
#execute if function sklibs:skapi_arrays/equal_r run return run function sklibs:skapi_arrays/continue

# demoS1作为遍历变量
data modify storage skapi.arrays temp.demoS1 set value 0

# 使用demoS1遍历demoS2并运行execute2函数
function sklibs:skapi_arrays/foreach {i:{data:"storage skapi.arrays temp.demoS1"},target:{data:"storage skapi.arrays demoS2"},execute:{value:"function sklibs:skapi_arrays/debug/demo1/execute2"}}
