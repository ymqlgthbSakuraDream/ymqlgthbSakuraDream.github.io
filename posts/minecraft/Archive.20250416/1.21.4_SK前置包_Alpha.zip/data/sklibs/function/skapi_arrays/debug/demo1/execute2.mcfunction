
tellraw @a [{"text":"   当前demoS1的值为："},{"nbt":"temp.demoS1","storage":"skapi.arrays"}]
