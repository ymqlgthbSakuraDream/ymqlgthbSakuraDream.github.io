
data modify storage skapi.arrays temp.s2aTemp set value {start:0,end:0}


execute store result score s2alen skapi.arrays.temp run data get storage skapi.arrays temp.s2aInput
execute store result storage skapi.arrays temp.s2aStringLength int 1 run scoreboard players get s2alen skapi.arrays.temp

scoreboard players set rangeStart skapi.arrays.temp 0
execute store result score rangeStop skapi.arrays.temp run data get storage skapi.arrays temp.s2aStringLength 1
scoreboard players set rangeStep skapi.arrays.temp 1
function sklibs:skapi_arrays/range
data modify storage skapi.arrays temp.s2aStringRange set from storage skapi.arrays temp.rangeOutput

data modify storage skapi.arrays temp.s2aOutput set value []

data modify storage skapi.arrays temp.foreachTarget set from storage skapi.arrays temp.s2aStringRange
data modify storage skapi.arrays temp.foreachTemp.cmd set value "function sklibs:skapi_arrays/private/string2array.run1"
data modify storage skapi.arrays temp.foreachTemp.i set value "storage skapi.arrays temp.s2aI"
function sklibs:skapi_arrays/foreach
