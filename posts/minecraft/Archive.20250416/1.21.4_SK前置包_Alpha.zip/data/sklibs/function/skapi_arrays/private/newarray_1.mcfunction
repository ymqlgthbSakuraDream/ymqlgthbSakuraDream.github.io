
data modify storage skapi.arrays temp.newarrOutput append from storage skapi.arrays temp.newarrFill
scoreboard players operation newarrLength skapi.arrays.temp -= 1 skapi.arrays.temp

execute if score newarrLength skapi.arrays.temp matches 1.. run function sklibs:skapi_arrays/private/newarray_1

