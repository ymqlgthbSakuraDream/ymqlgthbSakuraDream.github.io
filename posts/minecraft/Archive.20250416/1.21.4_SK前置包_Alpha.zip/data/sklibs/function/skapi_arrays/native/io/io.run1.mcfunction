
function sklibs:skapi_arrays/native/io/io.datatype {format:"\"s\"",input:"storage skapi.arrays temp.ioTemp.input",output:"ioDatatypeTemp skapi.arrays.temp"}
execute if score ioDatatypeTemp skapi.arrays.temp matches 1 run data modify storage skapi.arrays temp.ioTemp.char1 set value "\""
