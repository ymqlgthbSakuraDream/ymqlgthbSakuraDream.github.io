
$data modify $(output) set from $(input)
