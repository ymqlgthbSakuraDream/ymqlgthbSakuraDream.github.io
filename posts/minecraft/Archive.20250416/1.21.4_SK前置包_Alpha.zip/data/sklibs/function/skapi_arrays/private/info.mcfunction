
$scoreboard players set infoType skapi.arrays.temp $(type)

$execute if score infoType skapi.arrays.temp matches 0 run tellraw @s "\u00a77[Skapi Array] [DEBUG] $(text)"
$execute if score infoType skapi.arrays.temp matches 1 run tellraw @s "\u00a7f[Skapi Array] [INFO] $(text)"
$execute if score infoType skapi.arrays.temp matches 2 run tellraw @s "\u00a7e[Skapi Array] [WARNING] $(text)"
$execute if score infoType skapi.arrays.temp matches 3 run tellraw @s "\u00a7c[Skapi Array] [ERROR] $(text)"
$execute if score infoType skapi.arrays.temp matches 4 run tellraw @s "\u00a74[Skapi Array] [CRITICAL] $(text)"

execute if score infoType skapi.arrays.temp matches 2..4 run return 0