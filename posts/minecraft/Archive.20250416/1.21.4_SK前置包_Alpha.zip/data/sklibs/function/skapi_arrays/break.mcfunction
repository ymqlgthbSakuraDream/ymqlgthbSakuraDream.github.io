
data modify storage skapi.arrays temp.whileStack[-1] set value []
return 0