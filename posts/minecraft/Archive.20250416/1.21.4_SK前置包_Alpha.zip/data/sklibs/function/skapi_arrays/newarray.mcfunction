


data modify storage skapi.arrays temp.newarrOutput set value []
execute if score newarrLength skapi.arrays.temp matches 1.. run function sklibs:skapi_arrays/private/newarray_1


