
scoreboard players operation newarrLength skapi.arrays.temp = loopI skapi.arrays.temp
data modify storage skapi.arrays temp.newarrFill set value 0
function sklibs:skapi_arrays/newarray

data modify storage skapi.arrays temp.foreachTarget set from storage skapi.arrays temp.newarrOutput
data modify storage skapi.arrays temp.foreachTemp.cmd set from storage skapi.arrays temp.loopcmd
data modify storage skapi.arrays temp.foreachTemp.i set value "storage skapi.arrays temp.foreachI.value"
function sklibs:skapi_arrays/foreach