
$data modify storage skapi.arrays temp.2strOutput set value '$(v)'
