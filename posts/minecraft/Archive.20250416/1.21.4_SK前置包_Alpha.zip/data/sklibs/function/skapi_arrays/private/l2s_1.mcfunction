
$data modify storage skapi.arrays temp.l2sA set value "$(a)$(b)"
