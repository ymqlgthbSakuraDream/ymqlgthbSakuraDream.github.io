
# range(start, stop, step, output(data))


execute if score rangeStep skapi.arrays.temp matches 0 run return run function sklibs:skapi_arrays/private/info {type:2,text:"请求一个不为0的步长值"}

data modify storage skapi.arrays temp.rangeOutput set value []
function sklibs:skapi_arrays/private/range_



