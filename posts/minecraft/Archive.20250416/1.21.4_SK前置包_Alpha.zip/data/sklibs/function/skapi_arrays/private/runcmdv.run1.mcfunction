

execute if data storage skapi.arrays temp.runcmdvI.args run function sklibs:skapi_arrays/private/runcmdv.run2 with storage skapi.arrays temp.runcmdvI
$execute unless data storage skapi.arrays temp.runcmdvI.args run $(cmd)