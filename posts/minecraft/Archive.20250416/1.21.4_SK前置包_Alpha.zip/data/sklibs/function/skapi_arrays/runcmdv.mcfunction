


data modify storage skapi.arrays temp.foreachTarget set from storage skapi.arrays temp.runcmdv
data modify storage skapi.arrays temp.foreachTemp.i set value "storage skapi.arrays temp.runcmdvI"
data modify storage skapi.arrays temp.foreachTemp.cmd set value "function sklibs:skapi_arrays/private/runcmdv.run1 with storage skapi.arrays temp.runcmdvI"
function sklibs:skapi_arrays/foreach

# function sklibs:skapi_arrays/runcmdv {cmdv:{value:[{cmd:"say 1",args:{}}]}}



