
data modify storage skapi.arrays temp.ioDatatype set value []
$data modify storage skapi.arrays temp.ioDatatype append value $(format)
$execute store success score $(output) run data modify storage skapi.arrays temp.ioDatatype append from $(input)