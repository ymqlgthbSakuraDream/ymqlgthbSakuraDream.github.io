
$execute store result $(output) $(oDataType) $(oScale) run scoreboard players get $(input)
