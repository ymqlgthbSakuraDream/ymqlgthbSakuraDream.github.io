
$scoreboard players operation $(output) = $(input)
