
$function sklibs:skapi_arrays/native/io/io {input:$(a),output:{data:"storage skapi.arrays temp.strcatArgs.a"}}
$function sklibs:skapi_arrays/native/io/io {input:$(b),output:{data:"storage skapi.arrays temp.strcatArgs.b"}}

function sklibs:skapi_arrays/private/strcat.run1 with storage skapi.arrays temp.strcatArgs

$function sklibs:skapi_arrays/native/io/io {input:{data:"storage skapi.arrays temp.strcatOutput"},output:$(a)}