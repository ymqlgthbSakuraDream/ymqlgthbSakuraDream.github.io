
function sklibs:skapi_arrays/equal {a:{data:"storage skapi.arrays temp.findI"},b:{data:"storage skapi.arrays temp.findFind"},output:{score:"findResult skapi.arrays.temp"}}
execute if score findResult skapi.arrays.temp matches 1 run return run function sklibs:skapi_arrays/break
