
$function sklibs:skapi_arrays/native/io/io {input:$(a),output:{data:"storage skapi.arrays temp.equalA"}}
$function sklibs:skapi_arrays/native/io/io {input:$(b),output:{data:"storage skapi.arrays temp.equalB"}}
execute store success score equalResult skapi.arrays.temp run data modify storage skapi.arrays temp.equalA set from storage skapi.arrays temp.equalB
function sklibs:skapi_arrays/not {input:{score:"equalResult skapi.arrays.temp"},output:{score:"equalResult skapi.arrays.temp"}}
# tellraw @a [{"score":{"name": "equalResult","objective": "skapi.arrays.temp"}}]
$function sklibs:skapi_arrays/native/io/io {input:{score:"equalResult skapi.arrays.temp"},output:$(output)}