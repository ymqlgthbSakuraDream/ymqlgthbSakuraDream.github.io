
scoreboard objectives add skapi.arrays.temp dummy "skapi.arrays.temp"
# scoreboard objectives add skapi.arrays.var dummy "skapi.arrays.var"

# const
    scoreboard players set 1 skapi.arrays.temp 1

# info
    scoreboard players add infoType skapi.arrays.temp 0

data remove storage skapi.arrays temp

data modify storage skapi.arrays temp.strwiddb set value {"Q":5,"W":5,"E":5,"R":5,"T":5,"Y":5,"U":5,"I":3,"O":5,"P":5,"A":5,"S":5,"D":5,"F":5,"G":5,"H":5,"J":5,"K":5,"L":5,"Z":5,"X":5,"C":5,"V":5,"B":5,"N":5,"M":5,"q":5,"w":5,"e":5,"r":5,"t":3,"y":5,"u":5,"i":1,"o":5,"p":5,"a":5,"s":5,"d":5,"f":4,"g":5,"h":5,"j":5,"k":4,"l":2,"z":5,"x":5,"c":5,"v":5,"b":5,"n":5,"m":5,"1":5,"2":5,"3":5,"4":5,"5":5,"6":5,"7":5,"8":5,"9":5,"0":5,"<":4,">":4,"-":5,"+":5}
