
data modify storage skapi.arrays temp.l2sM.a set from storage skapi.arrays temp.l2sA
data modify storage skapi.arrays temp.l2sM.b set from storage skapi.arrays temp.l2s[0]
data remove storage skapi.arrays temp.l2s[0]

function sklibs:skapi_arrays/private/l2s_1 with storage skapi.arrays temp.l2sM
execute if data storage skapi.arrays temp.l2s[0] run function sklibs:skapi_arrays/private/l2s
