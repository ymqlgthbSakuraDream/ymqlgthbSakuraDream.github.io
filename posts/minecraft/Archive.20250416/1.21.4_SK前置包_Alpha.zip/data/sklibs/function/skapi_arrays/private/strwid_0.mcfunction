


scoreboard players set strwid_a skapi.arrays.temp 8
$execute if data storage skapi.arrays temp.strwiddb."$(value)" store result score strwid_a skapi.arrays.temp run data get storage skapi.arrays temp.strwiddb."$(value)" 1

scoreboard players operation strwid0 skapi.arrays.temp += strwid_a skapi.arrays.temp
scoreboard players add strwid0 skapi.arrays.temp 1
