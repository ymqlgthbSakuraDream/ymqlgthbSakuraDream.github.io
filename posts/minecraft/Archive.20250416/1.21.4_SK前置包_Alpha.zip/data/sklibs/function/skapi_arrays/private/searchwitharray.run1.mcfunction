
function sklibs:skapi_arrays/search {find:{data:"storage skapi.arrays temp.swaI"},target:{data:"storage skapi.arrays temp.swaTarget"},output:{data:"storage skapi.arrays temp.swaOutputTemp"}}
function sklibs:skapi_arrays/extend {a:{data:"storage skapi.arrays temp.swaOutput"},b:{data:"storage skapi.arrays temp.swaOutputTemp"}}