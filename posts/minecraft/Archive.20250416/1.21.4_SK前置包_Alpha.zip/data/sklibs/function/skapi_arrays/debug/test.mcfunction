
$say $(searchI),$(searchFind)