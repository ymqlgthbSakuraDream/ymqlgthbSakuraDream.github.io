
function sklibs:skapi_arrays/equal {a:{data:"storage skapi.arrays temp.searchI"},b:{data:"storage skapi.arrays temp.searchFind"},output:{score:"searchResult skapi.arrays.temp"}}
# tellraw @a [{"score":{"name": "searchResult","objective": "skapi.arrays.temp"}}]
execute if score searchResult skapi.arrays.temp matches 1 run function sklibs:skapi_arrays/private/search.run2
scoreboard players add searchIndex skapi.arrays.temp 1
