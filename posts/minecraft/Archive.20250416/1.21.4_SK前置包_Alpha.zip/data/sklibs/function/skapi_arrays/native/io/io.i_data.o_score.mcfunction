
$execute store result score $(output) run data get $(input)$(char2)$(iScale)
