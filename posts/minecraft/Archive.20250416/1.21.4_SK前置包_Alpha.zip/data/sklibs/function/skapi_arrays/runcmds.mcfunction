

data modify storage skapi.arrays temp.foreachTarget set from storage skapi.arrays temp.runcmds
data modify storage skapi.arrays temp.foreachTemp.cmd set value "function sklibs:skapi_arrays/private/runcmds.run1 with storage skapi.arrays temp.runcmdsI"
data modify storage skapi.arrays temp.foreachTemp.i set value "storage skapi.arrays temp.runcmdsI.value"
function sklibs:skapi_arrays/foreach

