
scoreboard players set searchIndex skapi.arrays.temp 0
data modify storage skapi.arrays temp.searchOutput set value []
$function sklibs:skapi_arrays/native/io/io {input:$(find),output:{data:"storage skapi.arrays temp.searchFind"}}
$function sklibs:skapi_arrays/native/io/io {input:$(target),output:{data:"storage skapi.arrays temp.searchTarget"}}
function sklibs:skapi_arrays/foreach {i:{data:"storage skapi.arrays temp.searchI"},target:{data:"storage skapi.arrays temp.searchTarget"},execute:{value:"function sklibs:skapi_arrays/private/search.run1"}}
$function sklibs:skapi_arrays/native/io/io {input:{data:"storage skapi.arrays temp.searchOutput"},output:$(output)}
