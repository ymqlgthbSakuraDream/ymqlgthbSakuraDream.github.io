


data modify storage skapi.arrays temp.l2sA set from storage skapi.arrays temp.l2s[0]
data remove storage skapi.arrays temp.l2s[0]

execute if data storage skapi.arrays temp.l2s[0] run function sklibs:skapi_arrays/private/l2s


