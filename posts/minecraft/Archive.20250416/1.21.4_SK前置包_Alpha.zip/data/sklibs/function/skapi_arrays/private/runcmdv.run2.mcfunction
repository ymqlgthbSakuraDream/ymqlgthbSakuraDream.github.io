
$$(cmd) $(args)
