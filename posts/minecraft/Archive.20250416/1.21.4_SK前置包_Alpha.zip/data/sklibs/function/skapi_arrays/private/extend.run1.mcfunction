
data modify storage skapi.arrays temp.extendA append from storage skapi.arrays temp.foreachI.value
