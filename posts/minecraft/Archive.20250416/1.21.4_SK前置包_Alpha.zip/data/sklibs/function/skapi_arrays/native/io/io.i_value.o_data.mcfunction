
$data modify $(output) set value $(char1)$(input)$(char1)
