

$say $(i)