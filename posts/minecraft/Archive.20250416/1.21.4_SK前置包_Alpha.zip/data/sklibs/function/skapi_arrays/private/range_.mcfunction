

execute store result storage skapi.arrays temp.rangeCurrentValue int 1.0 run scoreboard players get rangeStart skapi.arrays.temp
data modify storage skapi.arrays temp.rangeOutput append from storage skapi.arrays temp.rangeCurrentValue
scoreboard players operation rangeStart skapi.arrays.temp += rangeStep skapi.arrays.temp
execute if score rangeStart skapi.arrays.temp < rangeStop skapi.arrays.temp run function sklibs:skapi_arrays/private/range_