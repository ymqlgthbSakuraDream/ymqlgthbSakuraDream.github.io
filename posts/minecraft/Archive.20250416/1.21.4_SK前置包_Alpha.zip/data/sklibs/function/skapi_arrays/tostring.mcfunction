
$function sklibs:skapi_arrays/native/io/io {input:$(input),output:{data:"storage skapi.arrays temp.2str.v"}}
function sklibs:skapi_arrays/private/tostring_ with storage skapi.arrays temp.2str
$function sklibs:skapi_arrays/native/io/io {input:{data:"storage skapi.arrays temp.2strOutput"},output:$(output)}
