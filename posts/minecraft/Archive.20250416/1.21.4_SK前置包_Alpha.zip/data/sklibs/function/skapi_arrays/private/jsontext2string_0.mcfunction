
$data modify storage skapi.arrays temp.jsontext set value $(v)
