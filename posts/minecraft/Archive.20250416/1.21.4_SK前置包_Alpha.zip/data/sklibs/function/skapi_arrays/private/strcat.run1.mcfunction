
$data modify storage skapi.arrays temp.strcatOutput set value "$(a)$(b)"
