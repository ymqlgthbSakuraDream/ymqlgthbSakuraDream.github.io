
data modify storage skapi.arrays temp.jsontextlist append from storage skapi.arrays temp.jsontextI."text"
