
$scoreboard players set $(output) $(input)
