
# foreach(i(data), target(data), execute(func))

##! 执行foreach头部 {storage skapi.arrays temp.foreachTemp}
execute unless data storage skapi.arrays temp.foreachTarget[0] run return run function sklibs:skapi_arrays/private/info {type:2,text:"被遍历的列表为空列表"}
data modify storage skapi.arrays temp.whileStack append from storage skapi.arrays temp.foreachTarget
data modify storage skapi.arrays temp.foreachTempStack append value {i:"",cmd:""}
data modify storage skapi.arrays temp.foreachTempStack[-1].i set from storage skapi.arrays temp.foreachTemp.i
data modify storage skapi.arrays temp.foreachTempStack[-1].cmd set from storage skapi.arrays temp.foreachTemp.cmd
function sklibs:skapi_arrays/private/foreach.run1 with storage skapi.arrays temp.foreachTempStack[-1]
data remove storage skapi.arrays temp.whileStack[-1]
data remove storage skapi.arrays temp.foreachTempStack[-1]



