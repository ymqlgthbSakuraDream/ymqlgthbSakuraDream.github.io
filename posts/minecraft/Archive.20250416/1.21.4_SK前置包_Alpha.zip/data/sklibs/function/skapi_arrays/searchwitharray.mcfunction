
data modify storage skapi.arrays temp.swaOutput set value []
$function sklibs:skapi_arrays/native/io/io {input:$(target),output:{data:"storage skapi.arrays temp.swaTarget"}}
$function sklibs:skapi_arrays/foreach {i:{data:"storage skapi.arrays temp.swaI"},target:$(find),execute:{value:"function sklibs:skapi_arrays/private/searchwitharray.run1"}}
$function sklibs:skapi_arrays/native/io/io {input:{data:"storage skapi.arrays temp.swaOutput"},output:$(output)}
