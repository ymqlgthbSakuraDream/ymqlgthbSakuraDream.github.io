

execute store result score s2aI skapi.arrays.temp run data get storage skapi.arrays temp.s2aI 1

scoreboard players operation s2aIadd1 skapi.arrays.temp = s2aI skapi.arrays.temp
scoreboard players operation s2aIadd1 skapi.arrays.temp += 1 skapi.arrays.temp
# data modify storage skapi.arrays temp.s2aTemp set value {start:0,end:0}
execute store result storage skapi.arrays temp.s2aTemp.start int 1.0 run scoreboard players get s2aI skapi.arrays.temp
execute store result storage skapi.arrays temp.s2aTemp.end int 1.0 run scoreboard players get s2aIadd1 skapi.arrays.temp
function sklibs:skapi_arrays/private/string2array.run2 with storage skapi.arrays temp.s2aTemp

