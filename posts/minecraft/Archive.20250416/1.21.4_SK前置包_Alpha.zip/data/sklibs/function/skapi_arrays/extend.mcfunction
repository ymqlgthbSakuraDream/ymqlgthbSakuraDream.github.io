

data modify storage skapi.arrays temp.foreachTarget set from storage skapi.arrays temp.extendB
data modify storage skapi.arrays temp.foreachTemp.cmd set value "function sklibs:skapi_arrays/private/extend.run1"
data modify storage skapi.arrays temp.foreachTemp.i set value "storage skapi.arrays temp.foreachI.value"

function sklibs:skapi_arrays/foreach
