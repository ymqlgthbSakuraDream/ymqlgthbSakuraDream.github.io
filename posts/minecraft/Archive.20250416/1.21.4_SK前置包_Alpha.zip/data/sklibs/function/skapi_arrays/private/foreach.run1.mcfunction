
data modify storage skapi.arrays temp.foreachI.value set from storage skapi.arrays temp.whileStack[-1][0]
##! 执行foreach体{storage skapi.arrays temp.whileStack[-1]} 当前I {storage skapi.arrays temp.foreachI.value}
data remove storage skapi.arrays temp.whileStack[-1][0]
$data modify $(i) set from storage skapi.arrays temp.foreachI.value
$$(cmd)
execute if data storage skapi.arrays temp.whileStack[-1][0] run function sklibs:skapi_arrays/private/foreach.run1 with storage skapi.arrays temp.foreachTempStack[-1]
