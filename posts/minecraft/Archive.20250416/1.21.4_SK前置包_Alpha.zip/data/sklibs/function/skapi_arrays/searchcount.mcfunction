
$function sklibs:skapi_arrays/search {find:$(find),target:$(target),output:{data:"storage skapi.arrays temp.searchCountTemp"}}
$function sklibs:skapi_arrays/len {input:{data:"storage skapi.arrays temp.searchCountTemp"},output:$(output)}