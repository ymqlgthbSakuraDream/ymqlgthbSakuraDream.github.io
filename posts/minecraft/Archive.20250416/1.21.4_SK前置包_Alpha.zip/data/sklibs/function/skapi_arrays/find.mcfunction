
$function sklibs:skapi_arrays/native/io/io {input:$(find),output:{data:"storage skapi.arrays temp.findFind"}}
$function sklibs:skapi_arrays/native/io/io {input:$(target),output:{data:"storage skapi.arrays temp.findTarget"}}
function sklibs:skapi_arrays/foreach {i:{data:"storage skapi.arrays temp.findI"},target:{data:"storage skapi.arrays temp.findTarget"},execute:{value:"function sklibs:skapi_arrays/private/find.run1"}}
$function sklibs:skapi_arrays/native/io/io {input:{score:"findResult skapi.arrays.temp"},output:$(output)}
