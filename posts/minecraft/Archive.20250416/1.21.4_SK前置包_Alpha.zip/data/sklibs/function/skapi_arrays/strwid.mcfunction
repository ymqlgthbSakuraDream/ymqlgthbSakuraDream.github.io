
data modify storage skapi.arrays temp.s2aInput set from storage skapi.arrays temp.strwid
function sklibs:skapi_arrays/string2list

scoreboard players set strwid0 skapi.arrays.temp 0
scoreboard players set strwid1 skapi.arrays.temp 0

data modify storage skapi.arrays temp.foreachTarget set from storage skapi.arrays temp.s2aOutput
data modify storage skapi.arrays temp.foreachTemp.cmd set value "function sklibs:skapi_arrays/private/strwid_0 with storage skapi.arrays temp.foreachI"
data modify storage skapi.arrays temp.foreachTemp.i set value "storage skapi.arrays temp.foreachI.value"
function sklibs:skapi_arrays/foreach


