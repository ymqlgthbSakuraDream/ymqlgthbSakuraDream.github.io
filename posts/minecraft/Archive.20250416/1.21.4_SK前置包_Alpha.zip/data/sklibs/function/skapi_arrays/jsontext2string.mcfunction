

function sklibs:skapi_arrays/private/jsontext2string_0 with storage skapi.arrays temp.jsontext
data modify storage skapi.arrays temp.jsontextlist set value []

data modify storage skapi.arrays temp.foreachTarget set from storage skapi.arrays temp.jsontext
data modify storage skapi.arrays temp.foreachTemp.cmd set value "function sklibs:skapi_arrays/private/jsontext2string_1"
data modify storage skapi.arrays temp.foreachTemp.i set value "storage skapi.arrays temp.jsontextI"
function sklibs:skapi_arrays/foreach

data modify storage skapi.arrays temp.l2s set from storage skapi.arrays temp.jsontextlist
function sklibs:skapi_arrays/list2string
data modify storage skapi.arrays temp.jsontextOutput set from storage skapi.arrays temp.l2sA
