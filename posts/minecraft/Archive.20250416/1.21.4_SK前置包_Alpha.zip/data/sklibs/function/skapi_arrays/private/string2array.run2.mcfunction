
$data modify storage skapi.arrays temp.s2aOutput append string storage skapi.arrays temp.s2aInput $(start) $(end)
