
execute summon marker run function sklibs:skapi_tools/postools/_0
setblock ~ ~ ~ air
