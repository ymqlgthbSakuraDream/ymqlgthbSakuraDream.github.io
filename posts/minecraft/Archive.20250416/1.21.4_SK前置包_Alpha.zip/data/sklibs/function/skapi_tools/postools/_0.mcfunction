

execute store result storage skapi.skapilib temp.postool.x1 int 1 run scoreboard players operation #postool.x1 skapi.skapilib = #postool.x2 skapi.skapilib
execute store result storage skapi.skapilib temp.postool.y1 int 1 run scoreboard players operation #postool.y1 skapi.skapilib = #postool.y2 skapi.skapilib
execute store result storage skapi.skapilib temp.postool.z1 int 1 run scoreboard players operation #postool.z1 skapi.skapilib = #postool.z2 skapi.skapilib

execute store result storage skapi.skapilib temp.postool.x2 int 1 store result score #postool.x2 skapi.skapilib store result score #postool.dx skapi.skapilib run data get entity @s Pos[0]
execute store result storage skapi.skapilib temp.postool.y2 int 1 store result score #postool.y2 skapi.skapilib store result score #postool.dy skapi.skapilib run data get entity @s Pos[1]
execute store result storage skapi.skapilib temp.postool.z2 int 1 store result score #postool.z2 skapi.skapilib store result score #postool.dz skapi.skapilib run data get entity @s Pos[2]

execute store result storage skapi.skapilib temp.postool.dx int 1 run scoreboard players operation #postool.dx skapi.skapilib -= #postool.x1 skapi.skapilib
execute store result storage skapi.skapilib temp.postool.dy int 1 run scoreboard players operation #postool.dy skapi.skapilib -= #postool.y1 skapi.skapilib
execute store result storage skapi.skapilib temp.postool.dz int 1 run scoreboard players operation #postool.dz skapi.skapilib -= #postool.z1 skapi.skapilib

function sklibs:skapi_tools/postools/_1 with storage skapi.skapilib temp.postool

kill @s
