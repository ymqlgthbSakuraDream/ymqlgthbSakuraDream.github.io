
scoreboard objectives add skapi.skapilib dummy
data modify storage skapi.skapilib temp set value {}
