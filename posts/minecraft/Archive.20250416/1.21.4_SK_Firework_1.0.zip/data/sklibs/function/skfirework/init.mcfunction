
scoreboard objectives add skapi.firework dummy
scoreboard objectives add skapi.firework.launchtime dummy

data modify storage skapi.skfirework temp set value {}

kill @e[type=minecraft:marker,tag=skfirework.e]
