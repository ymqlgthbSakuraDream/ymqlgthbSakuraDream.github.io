

function sklibs:skfirework/fx/spread/_0.macro_0 with storage skapi.skfirework temp.args01_a

execute summon marker run function sklibs:skfirework/fx/spread/_1.summ with storage skapi.skfirework temp.args01

scoreboard players remove in.n skapi.firework 1
execute if score in.n skapi.firework matches 1.. run function sklibs:skfirework/fx/spread/_0

