
$execute store result storage skapi.skfirework temp.args02_01.rand int 1 run random value 0..$(len)

function sklibs:skfirework/fx/firework/_1.randcol_2 with storage skapi.skfirework temp.args02_01
