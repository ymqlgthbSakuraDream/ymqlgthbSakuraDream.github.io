
scoreboard players remove @s skapi.firework.launchtime 1
# tellraw @a [{"type": "score","score": {"name": "@s","objective": "skapi.firework.launchtime"}},{"type": "nbt","entity": "@s","nbt":"UUID"},{"color": "aqua","type": "text","text":"OOO"},{"type": "nbt","entity": "@s","nbt":"Life"}]
execute if score @s skapi.firework.launchtime matches ..1 run function sklibs:skfirework/fx/launch/_tick_1.runc with entity @s
