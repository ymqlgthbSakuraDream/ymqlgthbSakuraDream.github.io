
$data modify storage skapi.skfirework temp.input02.colors set from storage skapi.skfirework temp.input02.colors[$(rand)]
