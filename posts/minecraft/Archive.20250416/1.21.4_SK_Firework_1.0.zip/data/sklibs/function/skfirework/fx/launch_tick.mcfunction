
execute as @e[tag=skfirework.lau] run function sklibs:skfirework/fx/launch/_tick_0
