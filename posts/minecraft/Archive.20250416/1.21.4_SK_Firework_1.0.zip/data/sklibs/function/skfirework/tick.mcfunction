

function sklibs:skfirework/fx/launch_tick
