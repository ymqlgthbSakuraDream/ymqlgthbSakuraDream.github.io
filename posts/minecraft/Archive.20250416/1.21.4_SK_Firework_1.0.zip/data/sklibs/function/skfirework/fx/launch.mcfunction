
$data modify storage skapi.skfirework temp.input03 set value $(config)

data modify storage skapi.skfirework temp.args03 set value {config:{shape:-1,life:0,tags:["skfirework.laut","skfirework.lau"]}}
data modify storage skapi.skfirework temp.args03.config.life set from storage skapi.skfirework temp.input03.life

function sklibs:skfirework/fx/firework with storage skapi.skfirework temp.args03
execute as @e[tag=skfirework.laut] run function sklibs:skfirework/fx/launch/_0.summ with entity @s


# function sklibs:skfirework/fx/launch
