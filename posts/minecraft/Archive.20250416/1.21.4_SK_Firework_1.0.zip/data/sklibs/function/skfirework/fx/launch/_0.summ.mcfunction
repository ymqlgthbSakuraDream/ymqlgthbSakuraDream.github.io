
data modify storage skapi.skfirework temp.laucmds append value {uuid:"",cmds:[]}
$data modify storage skapi.skfirework temp.laucmds[-1].uuid set value "$(UUID)"
data modify storage skapi.skfirework temp.laucmds[-1].cmds set from storage skapi.skfirework temp.input03.cmdv

execute store result score @s skapi.firework.launchtime run data get storage skapi.skfirework temp.input03.life

tag @s remove skfirework.laut
