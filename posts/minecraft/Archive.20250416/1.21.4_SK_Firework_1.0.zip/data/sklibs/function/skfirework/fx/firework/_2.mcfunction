

execute summon firework_rocket run function sklibs:skfirework/fx/firework/_3.summ with storage skapi.skfirework temp.args02

scoreboard players remove in.n1 skapi.firework 1
execute if score in.n1 skapi.firework matches 1.. run function sklibs:skfirework/fx/firework/_2
