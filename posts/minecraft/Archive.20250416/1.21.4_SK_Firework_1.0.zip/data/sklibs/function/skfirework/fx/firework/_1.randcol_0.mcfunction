
execute store result score in.len skapi.firework run data get storage skapi.skfirework temp.input02.colors
scoreboard players remove in.len skapi.firework 1


execute store result storage skapi.skfirework temp.args02_01.len int 1 run scoreboard players get in.len skapi.firework

function sklibs:skfirework/fx/firework/_1.randcol_1 with storage skapi.skfirework temp.args02_01
