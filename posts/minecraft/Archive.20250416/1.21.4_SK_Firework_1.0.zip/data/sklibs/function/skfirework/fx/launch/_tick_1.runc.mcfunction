
$data modify storage skapi.arrays temp.runcmdv set from storage skapi.skfirework temp.laucmds[{uuid:"$(UUID)"}].cmds
execute at @s run function sklibs:skapi_arrays/runcmdv
$data remove storage skapi.skfirework temp.laucmds[{uuid:"$(UUID)"}]