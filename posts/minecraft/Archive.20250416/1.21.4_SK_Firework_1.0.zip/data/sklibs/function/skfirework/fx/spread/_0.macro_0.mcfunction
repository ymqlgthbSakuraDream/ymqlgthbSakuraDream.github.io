

$execute store result storage skapi.skfirework temp.args01.pitch int 1 run random value $(pitch0)..$(pitch1)
$execute store result storage skapi.skfirework temp.args01.yaw int 1 run random value $(yaw0)..$(yaw1)
$execute store result storage skapi.skfirework temp.args01.t int 1 run random value $(t0)..$(t1)
