
$data merge entity @s $(s)
# tellraw @a [{"color": "aqua","type": "text","text":""},{"type": "nbt","entity": "@s","nbt":"UUID"},{"type": "nbt","entity": "@s","nbt":"LifeTime"}]