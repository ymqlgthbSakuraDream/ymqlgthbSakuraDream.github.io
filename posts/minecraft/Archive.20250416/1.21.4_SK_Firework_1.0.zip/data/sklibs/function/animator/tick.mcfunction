
execute as @e[tag=skanimator.text] at @s run function sklibs:animator/tick/textanimator/_0
execute as @e[tag=skanimator.phy] at @s run function sklibs:animator/tick/physical/_0
