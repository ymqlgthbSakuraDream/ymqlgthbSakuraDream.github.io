
$data modify storage skapi.arrays temp.runcmdv set value $(tick_cmds)
function sklibs:skapi_arrays/runcmdv
