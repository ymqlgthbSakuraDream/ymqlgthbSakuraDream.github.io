

$data modify storage skapi.arrays temp.runcmdv set value $(cmds)
function sklibs:skapi_arrays/runcmdv
tag @s remove skanimator.phy

