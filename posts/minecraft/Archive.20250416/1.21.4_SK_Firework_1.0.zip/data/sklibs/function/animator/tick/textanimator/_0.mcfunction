

# 将当前帧转为16进制
scoreboard players operation dec.input skapi.math = @s skapi.animator.thisframe
function sklibs:skapi_math/dec2hex
data modify storage skapi.animator temp.args2.uni set from storage skapi.math temp.hexString 

scoreboard players operation dec.input skapi.math = @s skapi.animator.color
function sklibs:skapi_math/dec2hex
data modify storage skapi.animator temp.args2.color set from storage skapi.math temp.hexString 

function sklibs:animator/tick/textanimator/_1 with storage skapi.animator temp.args2
data modify entity @s text set from storage skapi.animator temp.text

scoreboard players add @s skapi.animator.thisframe 1
execute if score @s skapi.animator.thisframe = @s skapi.animator.targetframe run kill @s