

$data modify storage skapi.animator temp.input set value $(config)

data modify storage skapi.animator temp.args1.tags set value []
data modify storage skapi.animator temp.args1.scale set value 1
data modify storage skapi.animator temp.args1.tags set from storage skapi.animator temp.input.tags
data modify storage skapi.animator temp.args1.scale set from storage skapi.animator temp.input.scale
data modify storage skapi.animator temp.args1.y set from storage skapi.animator temp.input.y

# 生成文本展示实体
execute summon text_display run function sklibs:animator/new/textanimator/_0 with storage skapi.animator temp.args1
