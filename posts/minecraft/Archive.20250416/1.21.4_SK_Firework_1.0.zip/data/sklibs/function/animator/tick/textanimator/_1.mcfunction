
$data modify storage skapi.animator temp.text set value '[{"type":"text","text":"\\u$(uni)","color":"#$(color)"}]'