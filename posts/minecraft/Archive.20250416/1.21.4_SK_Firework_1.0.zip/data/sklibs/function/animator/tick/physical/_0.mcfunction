
execute store result storage skapi.animator temp.args1.vx double 0.001 run scoreboard players get @s skapi.animator.phy.vx
execute store result storage skapi.animator temp.args1.vy double 0.001 run scoreboard players get @s skapi.animator.phy.vy

function sklibs:animator/tick/physical/_3.tick_0 with entity @s
function sklibs:animator/tick/physical/_1.move with storage skapi.animator temp.args1

scoreboard players operation @s skapi.animator.phy.vy -= @s skapi.animator.phy.g
scoreboard players remove @s skapi.animator.phy.t 1

execute if score @s skapi.animator.phy.t matches ..0 run function sklibs:animator/tick/physical/_2.del_0 with entity @s

