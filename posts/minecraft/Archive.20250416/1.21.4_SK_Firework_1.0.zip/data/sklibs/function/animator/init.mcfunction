
# 清缓存
data modify storage skapi.animator temp set value {}

# textanimator

    # 当前帧
    scoreboard objectives add skapi.animator.thisframe dummy

    # 目标帧
    scoreboard objectives add skapi.animator.targetframe dummy

    # 颜色
    scoreboard objectives add skapi.animator.color dummy

# physical

    # 视线方向速度，垂直方向速度，重力加速度
    scoreboard objectives add skapi.animator.phy.vx dummy
    scoreboard objectives add skapi.animator.phy.vy dummy
    scoreboard objectives add skapi.animator.phy.g dummy
    scoreboard objectives add skapi.animator.phy.t dummy

