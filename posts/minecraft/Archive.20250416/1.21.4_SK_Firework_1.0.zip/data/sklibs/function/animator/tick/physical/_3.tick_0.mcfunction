
$function sklibs:animator/tick/physical/_3.tick_1 with storage skapi.animator temp.phycmds[{uuid:"$(UUID)"}]
