
$function sklibs:animator/tick/physical/_2.del_1 with storage skapi.animator temp.phycmds[{uuid:"$(UUID)"}]
$data remove storage skapi.animator temp.phycmds[{uuid:"$(UUID)"}]
