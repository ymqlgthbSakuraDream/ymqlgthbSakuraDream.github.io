
data modify storage skapi.animator temp.phycmds append value {uuid:"",cmds:[],tick:[]}
$data modify storage skapi.animator temp.phycmds[-1].uuid set value "$(UUID)"
data modify storage skapi.animator temp.phycmds[-1].cmds set from storage skapi.animator temp.input.cmdv
data modify storage skapi.animator temp.phycmds[-1].tick_cmds set from storage skapi.animator temp.input.tick_cmdv
