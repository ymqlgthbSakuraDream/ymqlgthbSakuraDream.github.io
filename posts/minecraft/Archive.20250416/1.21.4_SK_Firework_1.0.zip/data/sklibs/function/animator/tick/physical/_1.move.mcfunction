
$tp @s ^ ^ ^$(vx)
$execute at @s run tp @s ~ ~$(vy) ~
